import pandas as pd
import os
import xlwings as xw

ubicaciones = {
    'VISA': 'Visa',
    'VISA DEBIT': 'Visa Debito',
    'MASTERCARD': 'Mastercard',
    'MASTERCARD DEBIT': 'Mastercard debito',
    'AMEX': 'AMEX FISERV',
    'MAESTRO': 'MAESTRO',
    'ARGENCARD': 'ARGENCARD'
}

def actualizar_hoja_maestra(folder_path, hoja_maestra_path):
    print("Iniciando proceso de actualización de hoja maestra...")
    try:
        # Leer el archivo maestro en un DataFrame
        wb = xw.Book(hoja_maestra_path)
        hoja_maestra = wb.sheets['Hoja1']  # Suponiendo que la hoja se llama 'Hoja1'
        df_maestro = hoja_maestra.used_range.options(pd.DataFrame, index=False, header=True).value
        
        # Para cada archivo en la carpeta
        for key, value in ubicaciones.items():
            file_name = f"filtered_{key.upper()}_combined.xlsx"
            file_path = os.path.join(folder_path, file_name)
            if os.path.isfile(file_path):
                print(f"Procesando archivo: {file_name}")
                
                # Leer el archivo de datos en un DataFrame
                df_nuevo = pd.read_excel(file_path, header=1)
                
                # Reiniciar los índices de los DataFrames
                df_maestro.reset_index(drop=True, inplace=True)
                df_nuevo.reset_index(drop=True, inplace=True)
                
                # Actualizar el DataFrame maestro con los nuevos datos
                df_maestro = pd.concat([df_maestro, df_nuevo], ignore_index=True)
                
                print(f"Datos actualizados en la hoja maestra para: {value}.")
        
        # Escribir el DataFrame maestro actualizado en el archivo maestro
        hoja_maestra.clear_contents()
        hoja_maestra.range('A1').options(index=False, header=True).value = df_maestro.values
        
        wb.save()
        wb.close()
        print("Proceso completado. Hoja maestra actualizada.")
    except Exception as e:
        print(f"Error: {str(e)}")

def process_folder(folder_path, hoja_maestra_path):
    actualizar_hoja_maestra(folder_path, hoja_maestra_path)

folder_path = 'C:\Python312\excelConverted\excelCrudo'
hoja_maestra_path = 'C:/Python312/CONVERSOR DE PLANILLA SAS v.5.xlsm'

process_folder(folder_path, hoja_maestra_path)
