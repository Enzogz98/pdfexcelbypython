import pandas as pd
import os

fixed_headers = [
    "Trx", "Fecha Pres Fecha", "Term/Lote/Cupon", "Tarj", "Plan Cuota", "T F", 
    "T.N.A. %", "Ventas con/Dto.", "Ventas sin/Dto.", "Dto. Arancel", 
    "Dto. Financ.", "Cod. Rechazo Mot. contrap."
]
    
def filter_excel(file_path):
    try:
        data = pd.read_excel(file_path, header=1)

        if 'AMEX' in file_path or 'ARGENCARD' in file_path:
            data.columns=fixed_headers

        if data.iloc[:, 0].isin(['Plan cuota', 'Venta ctdo']).any():
            filtered_data = data[data.iloc[:, 0].isin(['Plan cuota', 'Venta ctdo'])]
            return filtered_data
        else:
            print(f"No se encontraron entradas válidas en la primera columna del archivo: {file_path}")
            return None
    except Exception as e:
        print(f"Error procesando el archivo {file_path}: {e}")
        return None
    

def process_folder(folder_path):
    files = [f for f in os.listdir(folder_path) if f.endswith('.xlsx')]
    output_folder_path = os.path.join(folder_path, 'excelCrudo')
    os.makedirs(output_folder_path, exist_ok=True)
    
    
    for file in files:
        file_path = os.path.join(folder_path, file)
        filtered_data=filter_excel(file_path)

            
        if filtered_data is not None:
            
            output_path = os.path.join(output_folder_path, f'filtered_{file}')
            filtered_data.to_excel(output_path, index=False)
            print(f'Archivo filtrado guardado en: {output_path}')

folder_path = 'C:\Python312\excelConverted'

process_folder(folder_path)
